function [GCIevi,res1] = yaga_region(x1,fs)
% x1=x1-mean(x1);
% x1 = filter([1 -0.94], 1, x1);
y1=abs(x1);


%%

w1=gausswin(20*fs/1000,4);

y2=filtfilt(w1,1,y1);

y2=y2/max(y2); y2(1)=0; y2(end)=0;

Th=1/25; 
vuv=y2-y2; 
vuv(y2>Th)=1;
pind=find(diff(vuv)==1);
nind=find(diff(vuv)==-1);
%% Merging the boundaries
vuv2=vuv;
for i=1:length(pind)-1
    
    D=pind(i+1)-nind(i);
    if(D<40*fs/1000)
        vuv2(nind(i):pind(i+1))=1;
    end
end
%% remvoing the false boundaries  
vuv3=vuv2;
pind=find(diff(vuv2)==1);
nind=find(diff(vuv2)==-1);

for i=1:length(pind)
    D=nind(i)-pind(i);
    if(D<30*fs/1000)
        vuv3(pind(i):nind(i))=0;
    end 
end
pind=find(diff(vuv3)==1);
nind=find(diff(vuv3)==-1);
GCIloc=[];
% epochs=[];
res1=[];
% evB=[];
% R1=[];
%   evZ=[];
%  x1=data8k;
if((length(pind)==1))
      [locs]=yaga(x1,fs);
% %   [locs,~,~] = dypsa(x1,fs);
%    
  GCIloc=locs';
  GCIevi=zeros(length(x1),1);
GCIevi(GCIloc)=1;
GCIevi=GCIevi(1:length(x1));
else
for i=1: length(pind)
    i
    if(i==1)

        reg1=x1(1:floor((nind(i)+pind(i+1))/2));

        t=1:floor((nind(i)+pind(i+1))/2);
    temppind=1;
    else

        if(i<length(pind))

            reg1=x1(floor((nind(i-1)+pind(i))/2)+1:floor((nind(i)+pind(i+1))/2));

            t=floor((nind(i-1)+pind(i))/2)+1:floor((nind(i)+pind(i+1))/2);
        temppind=floor((nind(i-1)+pind(i))/2);
        else

            reg1=x1(floor((nind(i-1)+pind(i))/2)+1:end);

            t=floor((nind(i-1)+pind(i))/2)+1:length(x1);
        temppind=floor((nind(i-1)+pind(i))/2);
        end

    end

 wave=reg1;
   [locs,~,res]=yaga(wave,fs);
res1=[res1;res];
%   [locs,~,~] = dypsa(wave,fs);
  locs=temppind+locs'; % make sure indexes MATCHES WITH ORIGINAL SIGNAL
%      
  GCIloc=[GCIloc;locs]; % storing the GCI evidence location
end
 GCIevi=zeros(length(x1),1);
GCIevi(GCIloc)=1;
GCIevi=GCIevi(1:length(x1));
end
end
