function [GCIevi] = SEDREAMS_rgion(x1,fs)
%   x1=x1-mean(x1);
   x1 = filter([1 -0.69], 1, x1);
%  x1=x1/max(abs(x1));
% 
 y1=abs(x1);
% 
% 
% %%
% 
w1=gausswin(20*fs/1000,4);

y2=filtfilt(w1,1,y1);

y2=y2/max(y2); y2(1)=0; y2(end)=0;

Th=1/25; 
vuv=y2-y2; 
vuv(y2>Th)=1;
%  [vnvsig] = VNVSig(x1,fs);
%  vuv=vnvsig;
pind=find(diff(vuv)==1);
nind=find(diff(vuv)==-1);
%% Merging the boundaries
vuv2=vuv;
for i=1:length(pind)-1
    
    D=pind(i+1)-nind(i);
    if(D<40*fs/1000)
        vuv2(nind(i):pind(i+1))=1;
    end
end
%% remvoing the false boundaries  
vuv3=vuv2;
pind=find(diff(vuv2)==1);
nind=find(diff(vuv2)==-1);
for i=1:length(pind)
    D=nind(i)-pind(i);
    if(D<30*fs/1000)
        vuv3(pind(i):nind(i))=0;
    end 
end
pind=find(diff(vuv3)==1);
nind=find(diff(vuv3)==-1);
GCIloc=[];
% epochs=[];
% res1=[];
% evB=[];
% R1=[];
%   evZ=[];
%  x1=data8k;
% if(length(pind)==1)
%     wave=x1;
%     [f0,~,~] = SRH_PitchTracking(wave,fs,80,240); 
%     F0mean=mean(f0)
%      [Polarity] = RESKEW_PolarityDetection(wave,fs);
%     [locs,res1] = SEDREAMS_GCIDetection(Polarity*wave,fs,F0mean);
% locs=locs'; % make sure indexes MATCHES WITH ORIGINAL SIGNAL
%  GCIloc=locs;
%  GCIevi=zeros(length(x1),1);
% GCIevi(GCIloc)=1;
% GCIevi=GCIevi(1:length(x1));
%  else
for i=1: length(pind)
  try
    if(i==1)

        reg1=x1(1:floor((nind(i)+pind(i+1))/2));

        t=1:floor((nind(i)+pind(i+1))/2);
    temppind=1;
    else
        i
        if(i<length(pind))

            reg1=x1(floor((nind(i-1)+pind(i))/2)+1:floor((nind(i)+pind(i+1))/2));

            t=floor((nind(i-1)+pind(i))/2)+1:floor((nind(i)+pind(i+1))/2);
        temppind=floor((nind(i-1)+pind(i))/2);
        else
    i
            reg1=x1(floor((nind(i-1)+pind(i))/2)+1:end);

            t=floor((nind(i-1)+pind(i))/2)+1:length(x1);
        temppind=floor((nind(i-1)+pind(i))/2);
        end

    end

 wave=reg1;
 wave=wave/max(abs(wave));
%  [Polarity] = RESKEW_PolarityDetection(wave,fs);
 [f0,VUVDecisions,SRHVal] = SRH_PitchTracking(wave,fs,80,500); % for extraction of f0
%    F0mean=mean(f0);
% %  F0mean=median(f0(VUVDecisions==1&f0>20&f0<300));
    VUVDecisions2=zeros(1,length(wave));
                    HopSize=round(10/1000*fs);
                    for k=1:length(VUVDecisions)
                        VUVDecisions2((k-1)*HopSize+1:k*HopSize)=VUVDecisions(k);
                    end
%                     Estimation of the mean pitch value
                    f0_tmp=f0.*VUVDecisions;
                    pos= f0_tmp~=0;
                    f0_tmp=f0_tmp(pos);
                    F0mean=(mean(f0_tmp));
                    % Oscillating Moment-based Polarity Detection
                    [Polarity] = RESKEW_PolarityDetection(wave,fs);
%   wave=abs(hilbert(wave));
[locs] = SEDREAMS_GCIDetection(Polarity*wave,fs,F0mean);
%    res=res';
% [res1]=[res1;res];
 locs=temppind+locs'; % make sure indexes MATCHES WITH ORIGINAL SIGNAL
 GCIloc=[GCIloc;locs];     
%   epochs=[epochs;epochs1]; % storing the GCI evidence location
% pause(4)
 catch
        continue
  end
end

% end
GCIevi=zeros(length(x1),1);
GCIevi(GCIloc)=1;
GCIevi=GCIevi(1:length(x1));
% wl=xcorrWinLen(reg1,fs)
% z=zeroFreqFilter(reg1,fs,WinLen);
end
% end
