function [epochs,zfSig1] = zpzff_region(x1,fs)
% x1=x1-mean(x1);
% x1=x1/max(abs(x1));
% x1 = filter([1 -0.85], 1, x1);
y1=abs(x1);


%%

w1=gausswin(20*fs/1000,4);
y2=filtfilt(w1,1,y1);
y2=y2/max(y2); y2(1)=0; y2(end)=0;
Th=1/25; 
vuv=y2-y2; 
vuv(y2>Th)=1;
pind=find(diff(vuv)==1);
nind=find(diff(vuv)==-1);
%% Merging the boundaries
vuv2=vuv;
for i=1:length(pind)-1
    
    D=pind(i+1)-nind(i);
    if(D<40*fs/1000)
        vuv2(nind(i):pind(i+1))=1;
    end
end
%% remvoing the false boundaries  
vuv3=vuv2;
pind=find(diff(vuv2)==1);
nind=find(diff(vuv2)==-1);
for i=1:length(pind)
    D=nind(i)-pind(i);
    if(D<30*fs/1000)
        vuv3(pind(i):nind(i))=0;
    end 
end
pind=find(diff(vuv3)==1);
nind=find(diff(vuv3)==-1);
epochs=[];
zfSig1=[];
% evB=[];
% R1=[];
%   evZ=[];
%  x1=data8k;
 if((length(pind)==1))
%  
% 
[WinLen]=xcorrWinLen(x1,fs);   % Window length for trend removal                           
[zfSig]=zp_zeroFreqFilter_tel(x1,fs,0.98,(WinLen),4); % ZFWinLenF Signal filter order 2 4 6 8 10 12
 [epochs1]=epochExtract_zpzff(zfSig);  % Epoch Extraction
%  [zfSig1]=[zfSig1;zfSig];
 epochs=epochs1;    
 else    
for i=1:length(pind)
    
    if(i==1)

        reg1=x1(1:floor((nind(i)+pind(i+1))/2));

        t=1:floor((nind(i)+pind(i+1))/2);
    temppind=1;
    else

        if(i<length(pind))

            reg1=x1(floor((nind(i-1)+pind(i))/2)+1:floor((nind(i)+pind(i+1))/2));

            t=floor((nind(i-1)+pind(i))/2)+1:floor((nind(i)+pind(i+1))/2);
        temppind=floor((nind(i-1)+pind(i))/2);
        else
i
            reg1=x1(floor((nind(i-1)+pind(i))/2)+1:end);

            t=floor((nind(i-1)+pind(i))/2)+1:length(x1);
        temppind=floor((nind(i-1)+pind(i))/2);
        end

    end

 wave=reg1;
%  dwav=wave;
% dwav=diff(wave); dwav(end+1)=dwav(end); % Difference the speech signal
% dwav=dwav/max(abs(dwav));
% wave=dwav;
%  wave=wave/abs(max(wave));
 [WinLen]=xcorrWinLen(wave,fs);   % Window length for trend removal                           
[zfSig]=zp_zeroFreqFilter_tel(wave,fs,0.98,(WinLen),4); % ZFWinLenF Signal filter order 2 4 6 8 10 12
zfSig=zfSig/max(abs(zfSig)); 
[epochs1]=epochExtract_zpzff(zfSig);  % Epoch Extraction
 [zfSig1]=[zfSig1;zfSig];
 zfSig1=zfSig1/max(abs(zfSig1)); 
 epochs=[epochs;epochs1]; % storing the GCI evidence location

end

end
end


