function [gci,goi,r] = yaga(s,fs,opt)

%   YAGA - Yet Another GCI Algorithm
%
%   Inputs:
%		s     is the speech signal
%		fs    is the sampling frequncy
%		opt   (Optional) 'v' applies VUS detection, 'p' makes useful plots, 'a'
%			applies Alku's IAIF (if available).
%
%   Outputs:
%		gci   is a vector of glottal closure sample numbers
%		goi   is a vector of glottal opening sample numbers
%	
%   External Functions:
%       Voicebox library required.
%
%	References:
%		M. R. P. Thomas, J. Gudnason and P. A. Naylor, "Estimation of Glottal 
%		Closing and Opening Instants in Voiced Speech using the YAGA Algorithm," 
%		in IEEE Trans. Audio, Speech, Lang. Process, Vol. 20, No. 1, pp 82-91,
%		2011.
%
%**************************************************************************
% Author:           M. R. P. Thomas, J. Gudnason, D. M. Brookes and P. A. Naylor
% Date:             6th March 2011
%**************************************************************************
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This program is free software; you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation; either version 2 of the License, or
%   (at your option) any later version.
%
%   This program is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You can obtain a copy of the GNU General Public License from
%   ftp://prep.ai.mit.edu/pub/gnu/COPYING-2.0 or by writing to
%   Free Software Foundation, Inc.,675 Mass Ave, Cambridge, MA 02139, USA.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if(nargin<3)
    opt='';
end
if(nargin>=3)
    if ~(any(opt=='v') || any(opt =='p') || any(opt == 'a') || isempty(opt))
        error('Argument ''opt'' can only be ''v'' or ''p'' for now. Stay tuned for more exciting options.');
    end
end

% Extract algorithm constants from VOICEBOX
dy_preemph=voicebox('dy_preemph');
dy_lpcstep=voicebox('dy_lpcstep');
dy_lpcdur=voicebox('dy_lpcdur');
dy_dopsp=voicebox('dy_dopsp');              % Use phase slope projection (1) or not (0)?
dy_ewtaper=voicebox('dy_ewtaper');        % Prediction order of FrobNorm method  in seconds
dy_ewlen=voicebox('dy_ewlen');        % windowlength of FrobNorm method  in seconds
dy_ewdly=voicebox('dy_ewdly');        % shift for assymetric speech shape at start of voiced cycle
dy_cpfrac=voicebox('dy_cpfrac');        % presumed ratio of larynx cycle that is closed
dy_lpcnf=voicebox('dy_lpcnf');          % lpc poles per Hz (1/Hz)
dy_lpcn=voicebox('dy_lpcn');            % lpc additional poles

lpcord=ceil(fs*dy_lpcnf+dy_lpcn);       % lpc poles

spp = s;

% DC removal by high-pass filter %
[b a] = butter(2,10/(fs/2),'high');
spf = filter(b,a,spp);

% MRPT's parameters
postGOI = 1;

if(any(opt=='a'))
    s_used=filter([1 -exp(-2*pi*dy_preemph/fs)],1,s);
    udash = iaif(s,fs,20,4,20,1);
else
    if~(fs==20000)
        warning('Inverse prototype not defined for fs!=20000. Consider using ''a'' option for IAIF instead'); 
    end
    iprotudash=[
        -0.533002849324892; 
        0.622127983250758;
        -0.058083131786265;
        -0.025840951313764;
        -0.002462576708046;
        0.002487699174393;
        -0.000280997739956;
        -0.002140389900568;
        -0.001615864970452;
        -0.000987664078621;
        -0.001220503224164;
        -0.001438863736837;
        -0.001176551923861;
        -0.000537854598417;
        0.000010322336443;
        0.000105351146253];
    
    s_used = fftfilt(iprotudash,spf);
    
    % perform LPC analysis, AC method with Hamming windowing
    [ar, e, Ts] = lpcauto(s_used,lpcord,floor([dy_lpcstep dy_lpcdur]*fs));
    udash = lpcifilt(spf,ar,Ts);    % Pad gives same alignment as original LPC residual.
end

% Calculate SWT
nlev=3;
mp = msprod(udash,'bior1.5',nlev);

% Find nth roots
nmp = mp;
nmp(find(nmp>0)) = 0;   % Half-wave rectify on negative half of mp for GCI
crnmp = nthroot(nmp,nlev);
r=crnmp;

% compute the group delay function:  EW method from reference [2] above
[zcr_cand,sew,gdwav,toff]=xewgrdel(r,fs); 
gdwav=-[zeros(toff,1); gdwav(1:end-toff)];
zcr_cand=[round(zcr_cand), ones(size(zcr_cand))];   %flag zero crossing candidates with ones

sew=0.5+sew';  %the phase slope cost of each candidate

pro_cand=[];
if dy_dopsp ~= 0
    pro_cand = psp(gdwav,fs);
    pro_cand = [pro_cand, zeros(length(pro_cand),1)]; %flag projected candidates with zeros
    sew =      [sew zeros(1,size(pro_cand,1))];      %the phase slope cost of a projected candidate is zero
end;

%Sort the zero crossing and projected candidates together and remove any candidates that
%are within 200 samples [0.01 s] from the speech boundary
[gcic,sin] = sortrows([zcr_cand; pro_cand],1);  
sew=sew(sin);
sin=find(and(0.01*fs<gcic,gcic<length(gdwav)-0.01*fs));
gcic=gcic(sin,:);
sew=sew(sin);

% compute the frobenious norm function used for a cost in the DP
fnwav=frobfun(s_used,dy_ewtaper*fs,dy_ewlen*fs,dy_ewdly*fs);    % Original

% Closed phase detection
u = filter(1,[1, -0.99],udash);     % Don't know why this works - better behaved than udash?
aencost = zeros(length(gcic),1);
for i=1:length(gcic)-1
    tmp = u(gcic(i,1):gcic(i+1,1));
    aencost(i)=(mean(tmp));
end
aencost = 0.5*aencost/mean(abs(aencost));
cencost = [0; aencost(1:end-1)];

[gci] = dpgci(gcic, udash(:), sew, fnwav, fs, aencost, any(opt=='v'));

% Remove GCIs from candidate set
if(nargout>1)
    [goic I] = setdiff(gcic(:,1),gci(:));
    goic = [goic gcic(I,2)];
    sewo = sew(I);
    cencost = cencost(I);
end

% Refine GCIs as per hybrid method.
k=findpeaks(-crnmp);
k=k(:);
tol=10; % Was 15 - not sure how to optimise this.

for ii=1:length(gci)    % This is faster but uglier than commented below
    jj=find(abs(k-gci(ii))<tol);
    if~isempty(jj)
        gci(ii) = k(jj);
    end
end

% Estimate GOIs
if(nargout>1)    
    % Generate matrix [goic(:), gci(:), CQ(:)]
    goic = goic(:,1);
    goic = goic(find(goic(:,1)>gci(1)),1);      %    Purge all < first GCI
    goic = [goic zeros(length(goic),2)];
    auggci = [gci inf];
    thisgci = 1;
    nextgci = 2;
    gciind = ones(size(auggci));
    gciindct = 2;
    for ii=1:length(goic)
        if(goic(ii)>auggci(thisgci))
            while(goic(ii,1)>auggci(nextgci) && thisgci<=length(auggci))
                thisgci = thisgci + 1;
                nextgci = nextgci + 1;
                gciind(gciindct) = ii;
                gciindct = gciindct+1;
            end
            
            goic(ii,2) = gci(thisgci);
            goic(ii,3) = (goic(ii,1)-gci(thisgci))/(auggci(nextgci)-auggci(thisgci));
        end
    end
    
    cq = 0.2;
    tol1 = 0.1;
    tol2 = tol1;     % Deviation from path
    cqsave=zeros(size(gci));
    goi = zeros(size(gci));
    for ii=2:length(gci)-1
        lastcqset = goic(gciind(ii-1):gciind(ii)-1,3);
        cqset = goic(gciind(ii):gciind(ii+1)-1,3);
        nextcqset = goic(gciind(ii+1):gciind(ii+2)-1,3);
        setlen = [length(lastcqset) length(cqset) length(nextcqset)];
        totlen = prod(setlen);
        
        % Find indices of all possible routes
        combidx = [floor(mod((0:totlen-1)'/(setlen(3)*setlen(2)),setlen(1)))+1,...
            floor(mod((0:totlen-1)'/(setlen(3)),setlen(2)))+1,...
            floor(mod((0:totlen-1)',setlen(3)))+1];
        
        % Find OQ values for all possible routes
        comb = [lastcqset(combidx(:,1)), cqset(combidx(:,2)), nextcqset(combidx(:,3))];
        
        % Find all paths whose deviation is within tolerance
        goodpth = sqrt(var(comb,0,2))<tol1;
        bestpthidx = find(goodpth,1,'first');
        
        if(~isempty(bestpthidx))
            if(abs(comb(bestpthidx,1))-cq<tol2)     % If it doesn't deviate far from current path
                goi(ii) = gci(ii)+(gci(ii+1)-gci(ii))*comb(bestpthidx,2);
                cq = mean(comb(bestpthidx,:));
                cqsave(ii) = comb(bestpthidx,2);
            else
                goi(ii) = gci(ii)+(gci(ii+1)-gci(ii))*cq;
                cqsave(ii) = cq;
            end
        else
            goi(ii) = gci(ii)+(gci(ii+1)-gci(ii))*cq;
            cqsave(ii)=cq;
        end
    end
    goi(1) = gci(1)+(gci(2)-gci(1))*cqsave(2);
    goi(ii+1) = gci(ii+1)+(gci(ii+1)-gci(ii))*cq;
    
    if(any(opt=='p'))
        ax(1) = subplot(3,1,1);
        plot(udash/max(abs(udash)));hold on;stem(goic(:,1),ones(size(goic(:,1))),'r');
        ax(2) = subplot(3,1,2);
        plot(u/max(abs(u)));hold on;stem(goic(:,1),ones(size(goic(:,1))),'r');
        ax(3) = subplot(3,1,3);
        scatter(goic(:,2),goic(:,3),4);hold on;
        ylim([0 1]);
        linkaxes(ax,'x');
        plot(gci,cqsave,'r');
        hold off;
        
        figure;
        t=0:1/fs:(length(s)-1)/fs;
        ax(1)=subplot(2,1,1);plot(t,s/max(abs(s)));
        title('(a)');
        ylabel('Normalized Amplitude');
        ax(2)=subplot(2,1,2);scatter(goic(:,2)/fs,goic(:,3),4);hold on;
        title('(b)');
        ylim([0 1]);
        box on;
        linkaxes(ax,'x');
        plot(gci/fs,cqsave,'r');
        hold off;
        linkaxes(ax,'x');
        ylabel('Closed Quotient');
        xlabel('Time (s)');
        xlim([0 gci(end)/fs]);
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function mp = msprod(x,ftype,nlev)
% Calculates multiscale product of x with wavelet ftype on lev levels
nu = length(x);
nU=(2^nlev)*ceil(nu./(2^nlev));
[Lo_D Hi_D] = wfilters(ftype,'d');
[swa swd] = swtalign([x; zeros(nU-nu,1)],nlev,Lo_D,Hi_D);
swa=swa(:,1:nu); swd=swd(:,1:nu);
mp = prod(swd)';

function z = psp(g,fs)
%PSP  Calculates the phase slope projections of the group delay function
%   Z = PSP(G) computes the 

%   Author(s): P. A. Naylor
%   Copyright 2002 Imperial College of Science Technology and Medicine, London
%   Revision History: 
%       V1.0 July 12th 2002:
%            Nov. 6th 2002 : if statement added to remove "last" midpoint 

g = g(:);

gdot = [diff(g);0];
gdotdot = [diff(gdot);0];

% find the turning points  as follows: [tp_number, index_of_tp, min(1) or max(-1), g(index_of_tp)]
turningPoints = zcr(gdot);

turningPoints = [[1:length(turningPoints)]', turningPoints, sign(gdotdot(turningPoints)), g(turningPoints)];

% useful for debug/plotting
%tplot = zeros(length(g),1);
%tplot(turningPoints(:,1)) = turningPoints(:,2);

% find any maxima which are < 0 
negmaxima = turningPoints(find(turningPoints(:,3) == -1 & turningPoints(:,4) < 0 & turningPoints(:,1)~=1),:);  %Change 01.05.2003 JG: The first row can't be included

% find the midpoint between the preceding min and the negative max
nmi = negmaxima(:,1);
midPointIndex = turningPoints(nmi-1,2) + round(0.5*(turningPoints(nmi,2) - turningPoints(nmi-1,2)));
midPointValue = g(midPointIndex);

% project a zero crossing with unit slope
nz = midPointIndex - round(midPointValue);

% find any minima which are > 0 
posminima = turningPoints(find(turningPoints(:,3) == 1 & turningPoints(:,4) > 0),:);

% find the midpoint between the positive min and the following max
pmi = posminima(:,1); 

%Remove last midpoint if it is the last sample
if ~isempty(pmi), if pmi(end)==size(turningPoints,1), pmi=pmi(1:end-1); end; end;

midPointIndex = turningPoints(pmi,2) + round(0.5*(turningPoints(pmi+1,2) - turningPoints(pmi,2)));
midPointValue = g(midPointIndex);

% project a zero crossing with unit slope
pz = midPointIndex - round(midPointValue);

z = sort([nz;pz]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function i = zcr(x, p)
%ZCR  Finds the indices in a vector to  zero crossings
%   I = ZCR(X) finds the indices of vector X which are closest to zero-crossings.
%   I = ZCR(X, P) finds indices for positive-going zeros-crossings for P=1 and
%   negative-going zero-crossings for P=0.

x = x(:);

if (nargin==2)
    if (p==0) 
        z1 = zcrp(x);   % find positive going zero-crossings
    elseif (p==1) 
        z1 = zcrp(-x);  % find negative going zero-crossings
    else
        error('ZCR: invalid input parameter 2: must be 0 or 1');
    end
else
    z1 = [zcrp(x); zcrp(-x)];
end

% find crossings when x==0 exactly
z0 = find( (x(1:length(x))==0) & ([x(2:length(x));0] ~= 0));

% concatenate and sort the two types of zero-crossings
i = sort([z0; z1]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function zz = zcrp(xx)  %only used in zcr
% find positive-going zero-crossing
z1 = find(diff(sign(xx)) == -2);
% find which out of current sample or next sample is closer to zero
[m, z2] = min([abs(xx(z1)), abs(xx(z1+1))], [], 2);
zz =  z1 -1 + z2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [frob]=frobfun(sp,p,m,offset)

% [frob]=frobfun(sp,p,m)
% 
% sp is the speech signal assumed to be preemphasised
% p  is the prediction order  : recomended to be 1 ms in above paper
% m  is the window length     : recomended to be 1 ms in above paper
% offset is shift for assymetric speech shape at start of voiced cycle -
% default 1.5ms.
%
% This function implements the frobenius norm based measure C defined in [4] below.
% It equals the square of the Frobenius norm of the m by p+1 data matrix divided by p+1
%
% Reference:
%   [4]  C. Ma, Y. Kamp, and L. F. Willems, �A Frobenius norm approach to glottal closure detection
%        from the speech signal,� IEEE Trans. Speech Audio Processing, vol. 2, pp. 258�265, Apr. 1994.


%   Author(s): J. Gudnason, P
%   Copyright 2002 Imperial College of Science Technology and Medicine, London
%   Revision History: 
%       V1.0 July 12th 2002:
%            Nov. 6th 2002 : if statement added to remove "last" midpoint 

%force p m and offset to be integers
p=round(p);
m=round(m);
offset=round(offset);

w=(p+1)*ones(1,m+p);
w(1:p)=1:p;
w(m+1:p+m)=p:-1:1;

w=w./(p+1); 
frob=filter(w,1,sp.^2);
frob(1:(round((p+m-1)/2) + offset))=[];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function goi=simplegci2goi(gci,pr)

% Estimate glottal opening instants by assuming a fixed closed-phase fraction

gci=round(gci);
maxpitch=max(medfilt1(diff(gci),7));

% calculate opening instants
for kg=1:length(gci)-1
    goi(kg)=gci(kg)+min(pr*(gci(kg+1)-gci(kg)),pr*maxpitch);
end;
kg=kg+1;
goi(kg)=round(gci(kg)+pr*(gci(kg)-gci(kg-1)));  %use the previous pitch period instead
goi=round(goi);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [tew,sew,y,toff]=xewgrdel(u,fs,dy_gwlen,dy_fwlen)

% implement EW group delay epoch extraction

%dy_gwlen=voicebox('dy_gwlen');          % group delay evaluation window length
%dy_fwlen=voicebox('dy_fwlen');          % window length used to smooth group delay

if(nargin<4)
    dy_fwlen = 0.00045;     % 0.00045 works well
end
if(nargin<3)
    dy_gwlen = 0.002;      % 0.002 works well
end

% perform group delay calculation

gw=2*floor(dy_gwlen*fs/2)+1;            % force window length to be odd
ghw=window('hamming',gw,'s');
ghw = ghw(:);                           % force to be a column (dmb thinks window gives a row - and he should know as he wrote it!)
ghwn=ghw'.*(gw-1:-2:1-gw)/2;            % weighted window: zero in middle

u2=u.^2;
yn=filter(ghwn,1,u2);
yd=filter(ghw,1,u2);
yd(abs(yd)<eps)=10*eps;                 % prevent infinities
y=yn(gw:end)./yd(gw:end);               % delete filter startup transient
toff=(gw-1)/2;
fw=2*floor(dy_fwlen*fs/2)+1;            % force window length to be odd
if fw>1
    daw=window('hamming',fw,'s');
    y=filter(daw,1,y)/sum(daw);         % low pass filter 
    toff=toff-(fw-1)/2;
end
[tew,sew]=zerocros(y,'n');              % find zero crossings

tew=tew+toff;                           % compensate for filter delay and frame advance


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Cfn=fnrg(gcic,frob,fs)

%Frobenious Energy Cost

dy_fxminf=voicebox('dy_fxminf');
frob=frob(:)';
mm=round(fs/dy_fxminf);
mfrob=maxfilt(frob,1,mm);
mfrob=[mfrob(floor(mm/2)+1:end) max(frob(end-ceil(mm/2):end))*ones(1,floor(mm/2))];
rfr=frob./mfrob;
Cfn=0.5-rfr(round(gcic));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [gci tvud]=dpgci(gcic, s, Ch, fnwav, fs, encost, vus)

%DPGCI   Choose the best Glottal Closure Instances with Dynamic Programming
%   gci=dpgci(gcic, s(:), Ch, fnwav, fs) returns vectors of sample indices corresponding
%   to the instants of glottal closure in the speech signal s at sampling frequency fs Hz.
%
%   Inputs:
%   gcic    is a matrix whos first column are the glottal closure instance candidates and
%           the second column is 1 if the corresponding gci is derived from a zero crossing 
%           but zero if the gci is from a a projected zero crossing
%   s       is the speech signal - MUST be a column vector
%   Ch      the phase slope cost of every candidate
%   fnwav   is the frobenious norm function of s
%   fs      is the sampling frequncy
%   encost  MRPT: cost for anticausal energy (for GCIs) and causal energy
%           (GOIs)
%
%   Outputs:
%   gci     is a vector of glottal closure instances chosen by the DP



%   Author(s): J. Gudnason, P.A. Naylor and D.M. Brookes
%   Copyright 2003 Imperial College London
%   Revision History: 
%   Bugs:  Constants are hardwired but defined in a structure like pv (defined in grpdelpv)
%         

% get algorithm parameters from voicebox()

dy_fxmin=voicebox('dy_fxmin');        % min larynx frequency (Hz)
dy_fxmax=voicebox('dy_fxmax');        % max larynx frequency (Hz)
dy_xwlen=voicebox('dy_xwlen');        % cross-correlation length for waveform similarity (sec)
dy_nbest=voicebox('dy_nbest');        % Number of NBest paths to keep
dy_spitch=voicebox('dy_spitch');              % scale factor for pitch deviation cost
wproj=voicebox('dy_cproj');           % cost of projected candidate
dy_cspurt=voicebox('dy_cspurt');           % cost of a talkspurt
dy_wpitch=voicebox('dy_wpitch');           % DP pitch weighting
dy_wener=voicebox('dy_wener');           % DP energy weighting
dy_wslope=voicebox('dy_wslope');           % DP group delay slope weighting
dy_wxcorr=voicebox('dy_wxcorr');           % DP cross correlation weighting

%Constants
Ncand=length(gcic);
sv2i=-(2*dy_spitch^2)^(-1);              % scale factor for pitch deviation cost

%Limit the search:
qrmin=ceil(fs/dy_fxmax);
qrmax=floor(fs/dy_fxmin);

% % MRPT: Cost saving
% savecosts = 1;
if(nargin<7)
    vus =0;
end

%Cost and tracking r = current, q = previous, p = preprevious
cost=zeros(Ncand, dy_nbest); cost(:,:)=inf;    %Cost matrix, one row for each candidate
maxcost=zeros(Ncand,1); maxcost(:,:)=inf;   %Maximum cost in each row
imaxcost=ones(Ncand,1);                     %Index of maximum cost

prev = ones(Ncand, dy_nbest);                  %index of previous, q candidates
ind = ones(Ncand, dy_nbest);                   %index of p in row q (from prev)
qbest = [zeros(Ncand,1), ones(Ncand,2)]; % the minimum cost in any previous q [cost,q,i]

% Temp: replace fnwav with crnmp
Cfn=fnrg(gcic(:,1),fnwav,fs);  %Frob.Energy Cost

%Add start and end state
% === should probably delete candidates that are too close to either end of the input
% === why do we ever need the additional one at the tail end ?
gcic=[[gcic(1,1)-qrmax-2 0];gcic;[gcic(end,1)+qrmax+2 0]];
Cfn=[0 Cfn 0];
Ch = [0 Ch 0];

% first do parallelized version

nxc=ceil(dy_xwlen*fs);       % cross correlation window length in samples
% === should delete any gci's that are within this of the end.
% === and for energy window
% rather complicated window specification is for compatibility with DYPSA 2
% === +1 below is for compatibility - probably a bug
wavix=(-floor(nxc/2):floor(nxc/2)+1)';                 % indexes for segments [nx2,1]
nx2=length(wavix);
sqnx2=sqrt(nx2);

if(nargin<6)
    g_cr=dy_wener*Cfn+dy_wslope*Ch+wproj*(1-gcic(:,2))';  % fixed costs
else
    dy_wen = 0.25; % Was 0.5
    g_cr=dy_wener*Cfn+dy_wslope*Ch+wproj*(1-gcic(:,2))'+dy_wen*[0 encost' 0];  % fixed costs
end


g_n=gcic(:,1)';                  % gci sample number [1,Ncand+2]
g_pr=gcic(:,2)';                 % unprojected flag [1,Ncand+2]
g_sqm=zeros(1,Ncand+1);         % stores: sqrt(nx2) * mean for speech similarity waveform
g_sd=zeros(1,Ncand+1);         % stores: 1/(Std deviation * sqrt(nx2)) for speech similarity waveform
f_pq=zeros((Ncand+1)*dy_nbest,1);   % (q-p) period for each node
f_c=repmat(Inf,(Ncand+1)*dy_nbest,1);    % cumulative cost for each node - initialise to inf
f_c(1)=0;                       % initial cost of zero for starting node
% f_costs=zeros(Ncand*dy_nbest,6);   % === debugging only remember costs of candidate
f_f=ones((Ncand+1)*dy_nbest,1);    % previous node in path
f_fb=ones((Ncand+1),1);    % points back to best end-of-spurt node
fbestc=0;                       % cost of best end-of-spurt node

qmin=2;
for r=2:Ncand+1   
    r_n=g_n(r);             % sample number of r = current candidate
    rix=dy_nbest*(r-1)+(1:dy_nbest);    % index range within node variables
    
    % determine the range of feasible q candidates
    qmin0=qmin;
    qmin=find(g_n(qmin0-1:r-1)<r_n-qrmax);      % qmin is the nearest candidate that is >qrmax away
    qmin=qmin(end)+qmin0-1;             % convert to absolute index of first viable candidate
    qmax=find(g_n(qmin-1:r-1)<=r_n-qrmin);      % qmax is the nearest candidate that is >=qrmin away
    qmax=qmax(end)+qmin-2;
    
    
    % calculate waveform similarity cost measure statistics
    sr=s(r_n+wavix);        % note s MUST be a column vector so sr is also
    wsum=sum(sr);
    g_sqm(r)=wsum/sqnx2;                % mean * sqrt(nx2)
    g_sd(r)=1/sqrt(sr.'*sr-wsum^2/nx2);   % 1/(Std deviation * sqrt(nx2))
    
    % now process the candidates
    
    if qmin<=qmax
        qix=qmin:qmax;      % q index
        nq=length(qix);
        % === should integrate the -0.5 into dy_wxcorr
        % === the factor (nx2-1)/(nx2-2) is to compensate for a bug in swsc()
        q_cas=-0.5*(nx2-1)/(nx2-2)*dy_wxcorr*(sum(s(repmat(g_n(qix),nx2,1)+repmat(wavix,1,nq)).*repmat(sr,1,nq),1)-g_sqm(qix)*g_sqm(r)).*g_sd(qix)*g_sd(r);
        % compare: i=35; Ca=swsc(g_n(qix(i)),g_n(r),s,fs); [i qix(i) r  g_n(qix(i)) g_n(r) dy_wxcorr*Ca q_cas(i)]
        
        % now calculate pitch deviation cost
        
        fix = 1+(qmin-1)*dy_nbest:qmax*dy_nbest;    % node index range
        f_qr=repmat(r_n-g_n(qix),dy_nbest,1);    % (r-p) period for each node
        f_pr=f_qr(:)+f_pq(fix);
        % === could absorb the 2 into sv2i
        f_nx=2-2*f_pr./(f_pr+abs(f_qr(:)-f_pq(fix)));
        f_cp=dy_wpitch*(0.5-exp(sv2i*f_nx.^2));
        % === fudge to match dypsa2.4 - could more efficiently be added
        % === onto the cost of a talkspurt end
        % === should be a voicebox parameter anyway
        f_cp(f_pq(fix)==0)=dy_cspurt*dy_wpitch;
        
        % now find the N-best paths
        
        [r_cnb,nbix]=sort(f_c(fix)+f_cp+reshape(repmat(q_cas,dy_nbest,1),nq*dy_nbest,1));
        f_c(rix)=r_cnb(1:dy_nbest)+g_cr(r);     % costs
        f_f(rix)=nbix(1:dy_nbest)+(qmin-1)*dy_nbest;       % traceback nodes
        f_pq(rix)=f_qr(nbix(1:dy_nbest));       % previous period
        if(vus)   % Currently no weights
            f_costs(rix,1)=reshape(q_cas(1+floor((nbix(1:dy_nbest)-1)/dy_nbest))./dy_wxcorr,dy_nbest,1);    % Waveform similarity
            f_costs(rix,2)=f_cp(nbix(1:dy_nbest))./dy_wpitch;      % Pitch deviation
            f_costs(rix,3)=(1-gcic(r,2))/2;         % Project candidate cost - weight in paper is 0.4 but weight is 0.2 as (1-gcic(r,2)) is bounded in [0,1].
            f_costs(rix,4)=Cfn(r);             % Frobenius Energy cost
            f_costs(rix,5)=Ch(r);             % Phase slope deviation cost
        end

        % check cost of using this candidate as the start of a new spurt
        % ==== the qmin>2 condition is for compatibility with dypsa 2 and
        % prevents any spurts starting until at least qrmax past the first
        % gci. This is probably a bug (see again below)
        iNb=rix(end);        
        if (qmin>2) && (f_c(f_fb(qmin-1))+wproj*(1-gcic(r,2))<f_c(iNb))        % compare with worst of Nbest paths
            f_f(iNb)=f_fb(qmin-1);
            % === for now we exclude the energy and phase-slope costs for compatibility with dypsa2
            % === this is probably a bug
            f_c(iNb)=f_c(f_fb(qmin-1))+wproj*(1-gcic(r,2));     % replace worst of the costs with start voicespurt cost
            f_pq(iNb)=0;                    % false pq period
        end
        if f_c(rix(1))<fbestc
            f_fb(r)=rix(1);                          % points to the node with lowest end-of-spurt cost
            % === should compensate for the pitch period cost incurred at the start of the next spurt
            % === note that a node can never be a one-node voicespurt on its own unless dy_nbest=1
            % since the start voices[purt option replaced the worst Nbest cost. This is probably good but
            % is a bit inconsistent.
            fbestc=f_c(rix(1));
        else
            f_fb(r)=f_fb(r-1);
        end
    else            % no viable candidates - must be the start of a voicespurt if anything
        % === for now we exclude the energy and phase-slope costs for compatibility with dypsa2
        % === this is probably a bug
        % ==== the qmin>2 condition is for compatibility with dypsa 2 and
        % prevents any spurts starting until at least qrmax past the first
        % gci. This is probably a bug (see again above)
        if (qmin>2)
            f_c(rix(1))=f_c(f_fb(qmin-1))+wproj*(1-gcic(r,2));  % cost of new voicespurt
            f_f(rix)=f_fb(qmin-1);                              % traceback to previous talkspurt end
            f_pq(rix)=0;                                        % previous period
        end
        f_fb(r)=f_fb(r-1);                                  % cannot be the end of a voicespurt
    end
end

% now do the traceback

gci = zeros(1,Ncand+1);

if(vus)
    mycost = zeros(Ncand+1,5);
end

% === for compatibility with dypsa2, we force the penultimate candidate to be accepted
% === should be: i=f_fb(Ncand+1) but instead we pick the best of the penultimate candidate
i=rix(1)-dy_nbest;
if f_c(i-dy_nbest+1)<f_c(i)     % check if start of a talkspurt
    i=i-dy_nbest+1;
end
k=1;
while i>1
    j=1+floor((i-1)/dy_nbest);          % convert node number to candidate number
    gci(k)=g_n(j);
    if(vus)
        mycost(k,:) = f_costs(i,:);
    end
    i=f_f(i);
    k=k+1;
end
gci=gci(k-1:-1:1);           % put into ascending order

% VUS detector
if(vus)
    mycost=mycost(k-1:-1:1,:);

    % Smooth waveform similarity
    dy_fwlen = 0.001;
    fw=2*floor(dy_fwlen*fs/2)+1;            % force window length to be odd
    daw=window('hamming',fw,'s');
    y=filter(daw,1,mycost(:,1))/sum(daw);         % low pass filter
    delay = (length(daw)+1)/2;
    y = [y(delay+1:end); zeros(delay, 1)];

    iV = y<-0.3;    % Horribly empirical threshold for voicing similarity
    
    % Kill any single or double bursts. Leaves holes in bursts length 3.
    iVr = [zeros(2,1); iV(1:end-2)] | [iV(2+1:end); zeros(2,1)];
    % Insert missing singles in both iV and (iV&iVr)
    iVi = (fftfilt([1 0 1], double(iV&iVr | iV))==2);
    % Filter out
    iV = ([iVi(2:end); 0] | (iV&iVr));
    
    vud = [0;diff(iV(:))];              % Nonzero at v/uv decision
    tvud = gci(find(vud));                   % Time of V/UV decision
    tvud = [tvud(:) zeros(size(tvud(:)))];   % V/UV decision polarity (1 voiced, 0 unvoiced)
    tvud(1:2:end,2) = 1;
    
    gciv = gci(iV);
    gciu = setdiff(gci,gciv);
    
    gci = gciv; 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function varargout = swtalign(x,n,varargin)
%SWT Discrete stationary wavelet transform 1-D. Differs from swt(...) in
%alignment of multiscale coefficients

nbIn = nargin;
if nbIn < 3
  error('Not enough input arguments.');
elseif nbIn > 4
  error('Too many input arguments.');
end
if errargt(mfilename,n,'int'), error('*'), end

% Use row vector.
x = x(:)';
s = length(x);
pow = 2^n;
if rem(s,pow)>0
    sOK = ceil(s/pow)*pow;
    msg = strvcat(...
            ['The level of decomposition ' int2str(n)],...
            ['and the length of the signal ' int2str(s)],...
            'are not compatible.',...
            ['Suggested length: ' int2str(sOK)],...
            '(see Signal Extension Tool)', ...
            ' ', ...
            ['2^Level has to divide the length of the signal.'] ...
            );
    errargt(mfilename,msg,'msg');
    varargout = {[] };
    return
end

% Compute decomposition filters.
if nargin==3
    [lo,hi] = wfilters(varargin{1},'d');
else
    lo = varargin{1};   hi = varargin{2};
end

% Set DWT_Mode to 'per'.
old_modeDWT = dwtmode('status','nodisp');
modeDWT = 'per';
dwtmode(modeDWT,'nodisp');

% Compute stationary wavelet coefficients.
evenoddVal = 0;
evenLEN    = 1;
swd = zeros(n,s);
swa = zeros(n,s);
for k = 1:n

    % Extension.
    lf = length(lo);
    x  = wextend('1D',modeDWT,x,lf/2);

    % Decomposition.
    swd(k,:) = wkeep1(wconv1(x,hi),s,lf);   % Default last arg was lf+1.
    swa(k,:) = wkeep1(wconv1(x,lo),s,lf);
    
    % upsample filters.
    lo = dyadup(lo,evenoddVal,evenLEN);
    hi = dyadup(hi,evenoddVal,evenLEN);

    % New value of x.
    x = swa(k,:);

end

if nargout==1
    varargout{1} = [swd ; swa(n,:)];
elseif nargout==2
    varargout = {swa,swd};
end     

% Restore DWT_Mode.
dwtmode(old_modeDWT,'nodisp');



