function linkaxes(varargin)
    warning('linkaxes is not implemented in Octave');
end
