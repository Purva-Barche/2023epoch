function [y,Fs] = audioread1(filename)

    [y,Fs] = wavread(filename);

return
