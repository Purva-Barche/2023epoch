function [y,Fs] = wavread(filename)

    [y,Fs] = audioread(filename);

return
