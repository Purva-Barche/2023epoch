function audiowrite(filename,y,Fs)

    wavwrite(y,Fs,filename)

return
