function[dglots,ifexc,t,E]=qcp_n(data,fs)
% [data,fs]=audioread('1-a_n.wav');
% data=resample(data,8000,fs);
% fs=8000;
wlen = 0.03*fs; % Frame length (sustained vowels, so long frame length is OK)
Nhop = 0.010*fs; % Hop size

if(fs==16000)
    p_vt = 24; % Vocal Tract filter order %24 for 16 Khz % 12 for 8 KHz
    p_vt2 = 24;
    p_g = 10; % Glottal Source model order %10 for 16khz  % 6 for 8 KHz
else
    p_vt = 12; % Vocal Tract filter order %24 for 16 Khz % 12 for 8 KHz
    p_vt2 = 12;
    p_g = 6; % Glottal Source model order %10 for 16khz  % 6 for 8 KHz
end
E_REF = 1; 
Ndata = length(data);
t=(0:length(data)-1)/fs; 
Nframes = floor((Ndata-wlen)/Nhop);
[f0vec2, ~] = estimate_f0(data,fs,wlen,Nhop,'ac');
meanf0 = median(f0vec2);
gcis = [];

lsf_general = zeros(Nframes,p_vt2);
lsf_vt = zeros(Nframes,p_vt);
lsf_g = zeros(Nframes,p_g);
E=zeros(Nframes,1);;
Evec = zeros(Nframes,1);
dglots = zeros(Nframes,wlen);
ifexc = zeros(1,length(data));
f0vec = zeros(Nframes,1);

sampleFrames = ones(size(data));

prevStop = 0;


for i = 1: Nframes
    if i > 2
        start = 1+(i-1)*Nhop;
        stop = start+wlen-1;
        start = start-p_vt;
    else
        start = 1;
        stop = start+wlen+p_vt-1;
    end
    frame = data(start:stop);
    E(i)=sum(frame.*frame );
    Evec(i) = 10*log10(sum(frame(p_vt+1:end).^2)/E_REF/wlen);
    if Evec(i) < -30
        VUVdata(i) = 0;
    end

    [gci_ins, ~] = gci(frame,meanf0,fs);
    
    gci_ins2 = gci_ins+start-1;
    gci_ins2 = gci_ins2(gci_ins2 > prevStop);
    prevStop = stop;
    gci_ins2 = gci_ins2(:)';
    gcis = [gcis, gci_ins2];
    
    [LSF_vt, LSF_g, dglot,~] = qcp(frame,p_vt,p_g,gci_ins,fs);
    
    lsf_vt(i,:) = LSF_vt;
    lsf_g(i,:) = LSF_g;
    frame2 = filter([1 -1],1,frame);
    a = lpc(frame2,p_vt2);
    lsf_a = poly2lsf(a);
    lsf_general(i,:) = lsf_a;
    %Evec(i) = norm(frame(p_vt+1:end)-mean(frame(p_vt+1:end)))/wlen;
    Evec(i) = 10*log10(sum(frame(p_vt+1:end).^2)/E_REF/wlen);
    Eframe = norm(frame(p_vt+1:end)-mean(frame(p_vt+1:end)));
    dglot = dglot/norm(dglot-mean(dglot))*Eframe;
    dglots(i,:) = dglot;
    
    
    ifexc(start+p_vt:stop) = ifexc(start+p_vt:stop)+dglots(i,:).*hann(wlen)';
    start2 = round(stop-wlen/2-Nhop/2);
    stop2 = start2+Nhop;
    sampleFrames(start2:stop2) = i;
end
end