% part of the Covarep project: http://covarep.github.io/covarep
%
% part of the Covarep project: http://covarep.github.io/covarep
%
clear all;
clear all;
path1='/Users/Rushil/Downloads/wavefilesforthesis';
files=dir(path1);
wavefile1=(fullfile(path1,files(5).name));
 [x1,fs] = audioread(wavefile1);
x1=resample(x1,8000,fs);
% x1=x1-mean(x1);
% x1 = filter([1 -0.8], 1, x1);
x1=x1/abs(max(x1));
fs=8000;
framed_x1=buffer(x1,820,300);
ener1=[];
for i=1:size(framed_x1,2)
    ener=sum(framed_x1(:,i).^2);
   ener1=[ener;ener1];
end
data=[framed_x1(:,15)];
f0vec2 = estimate_f0(x1,fs,160,80,'ac');
meanf0 = median(f0vec2);
[gci_ins, ~] = gci(data,meanf0,fs);
[vt1, ~, dgloth,~, vt] = qcp( data,12,6, gci_ins, fs );

Eframe = norm(data-mean(data));
dgloth = dgloth/norm(dgloth-mean(dgloth))*Eframe;

dglot2h=dgloth;

% dglot2h=(dglot2h/norm(dglot2h));
% [gf_iaif1,~] = iaif_ola(x1,fs);    % Glottal flow (and derivative) by the IAIF method
%  [~,~,~,zf1,~,~,~]=EPOCH_SOE_F0_ZFF(x1,fs);
%  [zf1, gci, winLength]=epochExtract(x1,fs);
%   [zf1,~]=tel_zp_zeroFreqFilter1(x1,fs,0.98);
%   zf1=zf1(721:end);
%  [WinLen]=xcorrWinLen(x1,8000) ;   % Window length for trend removal                          
%  [zf1]=zp_zeroFreqFilter_tel(x1,8000,0.98,WinLen,4);
% %  [~,~,zf1,gci,es,f0] = zff_analysis(x1,fs);
  data=data/max(abs(data));
t=(0:length(data)-1)/fs;  
t1=(0:length(dglot2h)-1)/fs;  
% [dglots,ifexc,t]=qcp_n(x1,fs);

fig(1) = subplot(231);
plot(t,data, 'b'); axis tight;
xlabel('Time [s]');
fig(2) = subplot(234);  
plot(t1,dglot2h, 'b'); 
xlabel('Time [s]');
% fig(3)=subplot(337);
% gdh=zeros(size(dglot2h,1),1);
% gdh=diff(dglot2h); gdh(end+1)=gdh(end);
% gdh=gdh/max(abs(gdh));
% plot(t1,gdh,'b')
 linkaxes(fig, 'x');
%%
wavefile2=(fullfile(path1,files(15).name));
[x2,fs] = audioread(wavefile2);
x2=resample(x2,8000,fs);
fs=8000;
framed_x2=buffer(x2,820,300);
ener2=[];
for i=3:size(framed_x2,2)
    ener=sum(framed_x2(:,i).^2);
   ener2=[ener;ener2];
end

data2=[framed_x2(:,15)];
f0vec2 = estimate_f0(x2,fs,160,80,'ac');
meanf0 = median(f0vec2);
[gci_ins, ~] = gci(data2,meanf0,fs);
[ ~, ~, dglotvd1,~, ~] = qcp( data2,12,6, gci_ins, fs );
Eframe = norm(data2-mean(data2));
dglotvd1 = dglotvd1/norm(dglotvd1-mean(dglotvd1))*Eframe;


%  [gf_iaif2,gfd_iaif] = iaif_ola(x2,fs);    % Glottal flow (and derivative) by the IAIF method
% %  [~,~,~,zf2,~,~,~]=EPOCH_SOE_F0_ZFF(x2,fs); 
%  [zf2,~]=tel_zp_zeroFreqFilter1(x2,fs,0.98);
% % [zf2, gci, winLength]=epochExtract(x2,fs);
% % [WinLen]=xcorrWinLen(x2,8000) ;   % Window length for trend removal                          
% % [zf2]=zp_zeroFreqFilter_tel(x2,8000,0.98,WinLen,4);
% zf2=zf2/max(abs(zf2));
 t2=(0:length(data2)-1)/fs;  
% [dglots,ifexc,t]=qcp_n(x1,fs);
data2=data2/max(abs(data2));

fig(4) = subplot(232);
plot(t2,data2, 'b'); 
xlabel('Time [s]');
fig(5) = subplot(235);  
t21=(0:length(dglotvd1)-1)/fs; 
plot(t21,(dglotvd1), 'b');
% gdvd1=zeros(size(dglot2vd1,1),1);
% gdvd1=diff(dglot2vd1); gdvd1(end+1)=gdvd1(end);
% gdvd1=gdvd1/max(abs(gdvd1));
xlabel('Time [s]');
% fig(6)=subplot(338);
% plot(t21,gdvd1,'b'); 
%%
wavefile3=(fullfile(path1,files(8).name));
[x3,fs] = audioread(wavefile3);
x3=resample(x3,8000,fs);
fs=8000;
framed_x3=buffer(x3,820,80);
% ener3=[];
% for i=3:size(framed_x3,2)
%     ener=sum(framed_x3(:,i).^2);
%    ener3=[ener;ener3];
% end
data3=[framed_x3(:,6)];
f0vec2 = estimate_f0(x3,fs,160,80,'ac');
meanf0 = median(f0vec2);
[gci_ins, ~] = gci(data2,meanf0,fs);
[ ~, ~, dglotvd2,~, ~] = qcp( data3,12,6, gci_ins, fs );
Eframe = norm(data3-mean(data3));
dglotvd2 = dglotvd2/norm(dglotvd2-mean(dglotvd2))*Eframe;

%  [gf_iaif3,gfd_iaif] = iaif_ola(x3,fs);    % Glottal flow (and derivative) by the IAIF method
% %  [~,~,~,zf3,~,~,~]=EPOCH_SOE_F0_ZFF(x3,fs); 
%  [zf3,~]=tel_zp_zeroFreqFilter1(x3,fs,0.98);
% %     [zf3, gci, winLength]=epochExtract(x3,fs);                     
% % [zf3]=zp_zeroFreqFilter_tel(x3,8000,0.98,WinLen,4); % ZFWinLenF Signal filter order 2 4 6 8 10 12
t3=(0:length(data3)-1)/fs; 
t31=(0:length(dglotvd2)-1)/fs; 

data3=data3/abs(max(data3));
% zf3=zf3/max(abs(zf3));
% [dglots,ifexc,t]=qcp_n(x1,fs);
fig(7) = subplot(233);
plot(t3,data3, 'b');axis tight;
xlabel('Time [s]');
% dglot2vd2=dglot2vd2/max(abs(dglot2vd2));
fig(8) = subplot(236);  
plot(t31,((dglotvd2)), 'b');

xlabel('Time [s]');
% gdvd2=zeros(size(dglotvd2,1),1);
% gdvd2=diff(dglot2vd2); gdvd2(end+1)=gdvd2(end);
% gdvd2=gdvd2/max(abs(gdvd2));
% fig(9)=subplot(339);
% plot(t31,gdvd2,'b'); 
% ylabel('Amplitude');
% fig(6) = subplot(313);  
% plot(t,ifexc, 'b');
% xlim([0 1])
  linkaxes(fig, 'x');