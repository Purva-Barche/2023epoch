# Epoch_Extraction_Results

Created for supporting the manuscript submitted to ICASSP-2021.

This repository have the state-of-the-art epoch extraction algorithms.

Some of the algorithms are taken from covarep toolbox (git@github.com:covarep/covarep.git)

Contact: Krishna Gurugubellli (krishna.gurugubelli@research.iiit.ac.in), and Purva sharma (purva.sharma@research.iiit.ac.in)
